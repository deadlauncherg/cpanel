const express = require('express');
const router = express.Router();
const fs = require('fs');
const { exec } = require('child_process');
const util = require('util');
const execAsync = util.promisify(exec);

// Load settings
function loadSettings() {
    try {
        if (fs.existsSync('settings.json')) {
            return JSON.parse(fs.readFileSync('settings.json', 'utf8'));
        }
    } catch (error) {
        console.error('Error loading settings:', error);
    }
    return { users: [], vps: [] };
}

function saveSettings(settings) {
    try {
        fs.writeFileSync('settings.json', JSON.stringify(settings, null, 4));
        return true;
    } catch (error) {
        console.error('Error saving settings:', error);
        return false;
    }
}

// Load VPS data
function loadVPSData() {
    try {
        if (fs.existsSync('vps_data.json')) {
            return JSON.parse(fs.readFileSync('vps_data.json', 'utf8'));
        }
    } catch (error) {
        console.error('Error loading VPS data:', error);
    }
    return {};
}

function saveVPSData(vpsData) {
    try {
        fs.writeFileSync('vps_data.json', JSON.stringify(vpsData, null, 4));
        return true;
    } catch (error) {
        console.error('Error saving VPS data:', error);
        return false;
    }
}

// Get system stats
async function getSystemStats() {
    try {
        const [cpu, memory, disk, uptime] = await Promise.all([
            execAsync("top -bn1 | grep 'Cpu(s)' | awk '{print $2}' | cut -d'%' -f1"),
            execAsync("free | grep Mem | awk '{printf \"%.1f\", $3/$2 * 100.0}'"),
            execAsync("df / | awk 'NR==2 {printf \"%.1f\", $5}'"),
            execAsync("uptime -p")
        ]);

        return {
            cpu: parseFloat(cpu.stdout) || 0,
            memory: parseFloat(memory.stdout) || 0,
            disk: parseFloat(disk.stdout) || 0,
            uptime: uptime.stdout.trim()
        };
    } catch (error) {
        console.error('Error getting system stats:', error);
        return { cpu: 0, memory: 0, disk: 0, uptime: 'Unknown' };
    }
}

// Get LXC containers
async function getLXCContainers() {
    try {
        const { stdout } = await execAsync('lxc list --format json');
        const containers = JSON.parse(stdout);

        const detailedContainers = await Promise.all(
            containers.map(async (container) => {
                try {
                    const [status, ip, resources] = await Promise.all([
                        execAsync(`lxc info ${container.name} | grep Status: | awk '{print $2}'`),
                        execAsync(`lxc list ${container.name} --format csv | cut -d, -f6`),
                        execAsync(`lxc config show ${container.name}`)
                    ]);

                    return {
                        name: container.name,
                        status: status.stdout.trim(),
                        ip: ip.stdout.trim(),
                        type: container.type,
                        created: container.created_at,
                        resources: resources.stdout
                    };
                } catch (error) {
                    return {
                        name: container.name,
                        status: 'Unknown',
                        ip: 'Unknown',
                        type: container.type,
                        created: container.created_at,
                        resources: 'Error fetching'
                    };
                }
            })
        );

        return detailedContainers;
    } catch (error) {
        console.error('Error getting LXC containers:', error);
        return [];
    }
}

// API Routes

// Get admin dashboard data
router.get('/dashboard', async (req, res) => {
    try {
        const settings = loadSettings();
        const vpsData = loadVPSData();
        const systemStats = await getSystemStats();
        const containers = await getLXCContainers();

        // Calculate statistics
        const totalUsers = settings.users.length;
        const totalVPS = Object.values(vpsData).reduce((sum, userVPS) => sum + userVPS.length, 0);
        const runningVPS = Object.values(vpsData).reduce((sum, userVPS) => 
            sum + userVPS.filter(vps => vps.status === 'running').length, 0
        );
        const suspendedVPS = Object.values(vpsData).reduce((sum, userVPS) => 
            sum + userVPS.filter(vps => vps.suspended).length, 0
        );

        res.json({
            success: true,
            data: {
                stats: {
                    totalUsers,
                    totalVPS,
                    runningVPS,
                    suspendedVPS,
                    system: systemStats
                },
                users: settings.users,
                containers,
                recentActivity: getRecentActivity()
            }
        });
    } catch (error) {
        console.error('Dashboard error:', error);
        res.status(500).json({ success: false, error: 'Internal server error' });
    }
});

// Add user
router.post('/users/add', async (req, res) => {
    try {
        const { username, password, email, role, name } = req.body;

        if (!username || !password || !email || !role || !name) {
            return res.status(400).json({ success: false, error: 'All fields are required' });
        }

        const settings = loadSettings();

        // Check if user already exists
        if (settings.users.find(u => u.username === username)) {
            return res.status(400).json({ success: false, error: 'Username already exists' });
        }

        // Add new user
        const newUser = {
            id: Date.now(),
            username,
            password, // In production, hash this password
            email,
            role,
            name,
            created: new Date().toISOString(),
            status: 'active'
        };

        settings.users.push(newUser);

        if (saveSettings(settings)) {
            res.json({ success: true, message: 'User added successfully', user: newUser });
        } else {
            res.status(500).json({ success: false, error: 'Failed to save user' });
        }
    } catch (error) {
        console.error('Add user error:', error);
        res.status(500).json({ success: false, error: 'Internal server error' });
    }
});

// Delete user
router.delete('/users/:id', async (req, res) => {
    try {
        const userId = parseInt(req.params.id);
        const settings = loadSettings();

        const userIndex = settings.users.findIndex(u => u.id === userId);
        if (userIndex === -1) {
            return res.status(404).json({ success: false, error: 'User not found' });
        }

        // Check if user has VPS
        const vpsData = loadVPSData();
        const userVPS = Object.values(vpsData).find(vpsList => 
            vpsList.some(vps => vps.owner === settings.users[userIndex].username)
        );

        if (userVPS && userVPS.length > 0) {
            return res.status(400).json({ 
                success: false, 
                error: 'Cannot delete user with active VPS. Delete VPS first.' 
            });
        }

        settings.users.splice(userIndex, 1);

        if (saveSettings(settings)) {
            res.json({ success: true, message: 'User deleted successfully' });
        } else {
            res.status(500).json({ success: false, error: 'Failed to delete user' });
        }
    } catch (error) {
        console.error('Delete user error:', error);
        res.status(500).json({ success: false, error: 'Internal server error' });
    }
});

// Suspend/Unsuspend user
router.post('/users/:id/suspend', async (req, res) => {
    try {
        const userId = parseInt(req.params.id);
        const { suspend } = req.body;

        const settings = loadSettings();
        const user = settings.users.find(u => u.id === userId);

        if (!user) {
            return res.status(404).json({ success: false, error: 'User not found' });
        }

        user.status = suspend ? 'suspended' : 'active';

        // Also suspend all user's VPS
        const vpsData = loadVPSData();
        Object.keys(vpsData).forEach(userId => {
            vpsData[userId].forEach(vps => {
                if (vps.owner === user.username) {
                    vps.suspended = suspend;
                    if (suspend && vps.status === 'running') {
                        vps.status = 'stopped';
                        // Actually stop the container
                        exec(`lxc stop ${vps.container_name}`, (error) => {
                            if (error) console.error(`Failed to stop VPS ${vps.container_name}:`, error);
                        });
                    }
                }
            });
        });

        if (saveSettings(settings) && saveVPSData(vpsData)) {
            res.json({ 
                success: true, 
                message: `User ${suspend ? 'suspended' : 'activated'} successfully` 
            });
        } else {
            res.status(500).json({ success: false, error: 'Failed to update user' });
        }
    } catch (error) {
        console.error('Suspend user error:', error);
        res.status(500).json({ success: false, error: 'Internal server error' });
    }
});

// Get all VPS
router.get('/vps', async (req, res) => {
    try {
        const vpsData = loadVPSData();
        const settings = loadSettings();

        const allVPS = [];
        Object.keys(vpsData).forEach(userId => {
            vpsData[userId].forEach(vps => {
                const user = settings.users.find(u => u.username === vps.owner);
                allVPS.push({
                    ...vps,
                    ownerName: user ? user.name : 'Unknown',
                    ownerEmail: user ? user.email : 'Unknown',
                    ownerStatus: user ? user.status : 'unknown'
                });
            });
        });

        res.json({ success: true, data: allVPS });
    } catch (error) {
        console.error('Get VPS error:', error);
        res.status(500).json({ success: false, error: 'Internal server error' });
    }
});

// Suspend/Unsuspend VPS
router.post('/vps/:name/suspend', async (req, res) => {
    try {
        const containerName = req.params.name;
        const { suspend } = req.body;

        const vpsData = loadVPSData();
        let vpsFound = false;

        Object.keys(vpsData).forEach(userId => {
            vpsData[userId].forEach(vps => {
                if (vps.container_name === containerName) {
                    vpsFound = true;
                    vps.suspended = suspend;
                    if (suspend && vps.status === 'running') {
                        vps.status = 'stopped';
                        exec(`lxc stop ${containerName}`, (error) => {
                            if (error) console.error(`Failed to stop VPS ${containerName}:`, error);
                        });
                    } else if (!suspend) {
                        vps.status = 'stopped'; // Will need to be started manually
                    }
                }
            });
        });

        if (!vpsFound) {
            return res.status(404).json({ success: false, error: 'VPS not found' });
        }

        if (saveVPSData(vpsData)) {
            res.json({ 
                success: true, 
                message: `VPS ${suspend ? 'suspended' : 'unsuspended'} successfully` 
            });
        } else {
            res.status(500).json({ success: false, error: 'Failed to update VPS' });
        }
    } catch (error) {
        console.error('Suspend VPS error:', error);
        res.status(500).json({ success: false, error: 'Internal server error' });
    }
});

// Delete VPS
router.delete('/vps/:name', async (req, res) => {
    try {
        const containerName = req.params.name;

        const vpsData = loadVPSData();
        let vpsFound = false;

        Object.keys(vpsData).forEach(userId => {
            const userVPS = vpsData[userId];
            const vpsIndex = userVPS.findIndex(vps => vps.container_name === containerName);

            if (vpsIndex !== -1) {
                vpsFound = true;
                userVPS.splice(vpsIndex, 1);

                // Remove user entry if no VPS left
                if (userVPS.length === 0) {
                    delete vpsData[userId];
                }
            }
        });

        if (!vpsFound) {
            return res.status(404).json({ success: false, error: 'VPS not found' });
        }

        // Delete the actual container
        exec(`lxc delete ${containerName} --force`, async (error) => {
            if (error) {
                console.error(`Failed to delete container ${containerName}:`, error);
                return res.status(500).json({ success: false, error: 'Failed to delete container' });
            }

            if (saveVPSData(vpsData)) {
                res.json({ success: true, message: 'VPS deleted successfully' });
            } else {
                res.status(500).json({ success: false, error: 'Failed to save VPS data' });
            }
        });
    } catch (error) {
        console.error('Delete VPS error:', error);
        res.status(500).json({ success: false, error: 'Internal server error' });
    }
});

// Helper function for recent activity
function getRecentActivity() {
    return [
        { action: 'User Login', user: 'admin', time: '2 minutes ago', type: 'info' },
        { action: 'VPS Created', user: 'john_doe', time: '15 minutes ago', type: 'success' },
        { action: 'VPS Suspended', user: 'admin', time: '1 hour ago', type: 'warning' },
        { action: 'User Added', user: 'admin', time: '2 hours ago', type: 'info' }
    ];
}

module.exports = router;