const express = require('express');
const router = express.Router();
const { exec } = require('child_process');
const util = require('util');
const fs = require('fs').promises;
const path = require('path');

// Promisify exec for async/await
const execAsync = util.promisify(exec);

// Load VPS data
const vpsDataPath = path.join(__dirname, '../../vps_data.json');

async function loadVPSData() {
    try {
        const data = await fs.readFile(vpsDataPath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.warn('vps_data.json not found or corrupted, initializing empty data');
        return {};
    }
}

async function saveVPSData(data) {
    try {
        await fs.writeFile(vpsDataPath, JSON.stringify(data, null, 4));
        return true;
    } catch (error) {
        console.error('Error saving VPS data:', error);
        return false;
    }
}

// Load settings to get users
function loadSettings() {
    try {
        if (require('fs').existsSync('settings.json')) {
            return JSON.parse(require('fs').readFileSync('settings.json', 'utf8'));
        }
    } catch (error) {
        console.error('Error loading settings.json:', error);
    }
    return { users: [] };
}

// LXC command execution with error handling
async function executeLXC(command, timeout = 120000) {
    try {
        const { stdout, stderr } = await execAsync(command, { timeout });

        if (stderr && !stderr.includes('Warning:') && !stderr.includes('info:') && stderr.trim() !== '') {
            throw new Error(stderr);
        }

        return stdout.trim() || true;
    } catch (error) {
        console.error(`LXC Error: ${command} - ${error.message}`);
        throw error;
    }
}

// Get Discord user ID from username (simplified - you may need to adjust this)
function getUserIdFromUsername(username) {
    const settings = loadSettings();
    const user = settings.users.find(u => u.username === username);
    return user ? user.id.toString() : null;
}

// Get available users for the dropdown
router.get('/users', async (req, res) => {
    try {
        const settings = loadSettings();
        const vpsData = await loadVPSData();

        // Get all users from settings
        const users = settings.users.map(user => ({
            id: user.id,
            username: user.username,
            name: user.name || user.username,
            role: user.role,
            email: user.email,
            vpsCount: vpsData[user.id] ? vpsData[user.id].length : 0
        }));

        res.json({
            success: true,
            data: users
        });
    } catch (error) {
        console.error('Error loading users:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to load users'
        });
    }
});

// Create new VPS
router.post('/create', async (req, res) => {
    try {
        const { username, vpsName, os, ram, cpu, disk } = req.body;

        console.log('Creating VPS with data:', { username, vpsName, os, ram, cpu, disk });

        // Validate required fields
        if (!username || !vpsName || !os || !ram || !cpu || !disk) {
            return res.status(400).json({
                success: false,
                error: 'All fields are required'
            });
        }

        // Validate VPS name format
        if (!/^[a-zA-Z0-9-_]+$/.test(vpsName)) {
            return res.status(400).json({
                success: false,
                error: 'VPS name can only contain letters, numbers, hyphens, and underscores'
            });
        }

        // Validate resource limits
        if (ram < 1 || ram > 32) {
            return res.status(400).json({
                success: false,
                error: 'RAM must be between 1GB and 32GB'
            });
        }

        if (cpu < 1 || cpu > 16) {
            return res.status(400).json({
                success: false,
                error: 'CPU cores must be between 1 and 16'
            });
        }

        if (disk < 10 || disk > 500) {
            return res.status(400).json({
                success: false,
                error: 'Disk size must be between 10GB and 500GB'
            });
        }

        // Get user ID from username
        const userId = getUserIdFromUsername(username);
        if (!userId) {
            return res.status(400).json({
                success: false,
                error: `User "${username}" not found in system`
            });
        }

        // Load current data
        const vpsData = await loadVPSData();

        // Initialize user's VPS array if it doesn't exist
        if (!vpsData[userId]) {
            vpsData[userId] = [];
        }

        // Check if user has too many VPS (optional limit)
        if (vpsData[userId].length >= 20) {
            return res.status(400).json({
                success: false,
                error: 'User has reached the maximum number of VPS instances (20)'
            });
        }

        // Check if VPS name already exists
        const vpsNameExists = Object.values(vpsData).some(vpsList => 
            vpsList.some(vps => vps.vps_name === vpsName)
        );

        if (vpsNameExists) {
            return res.status(400).json({
                success: false,
                error: `VPS name "${vpsName}" is already in use`
            });
        }

        // Generate container name
        const vpsCount = vpsData[userId].length + 1;
        const containerName = `unixnodes-vps-${userId}-${vpsCount}`;
        const ramMB = ram * 1024;

        console.log(`Creating container: ${containerName}`);

        // Create the VPS using LXC
        try {
            // Initialize container
            console.log(`Initializing container with OS: ${os}`);
            await executeLXC(`lxc init ${os} ${containerName} --storage default`);

            // Set resource limits
            console.log(`Setting memory limit: ${ramMB}MB`);
            await executeLXC(`lxc config set ${container_name} limits.memory ${ramMB}MB`);

            console.log(`Setting CPU limit: ${cpu} cores`);
            await executeLXC(`lxc config set ${container_name} limits.cpu ${cpu}`);

            console.log(`Setting disk size: ${disk}GB`);
            await executeLXC(`lxc config device set ${container_name} root size ${disk}GB`);

            // Start the container
            console.log('Starting container...');
            await executeLXC(`lxc start ${container_name}`);

            // Wait for the container to fully start
            console.log('Waiting for container to initialize...');
            await new Promise(resolve => setTimeout(resolve, 10000));

            // Check if container is running
            const status = await executeLXC(`lxc info ${container_name} | grep "Status:" | awk '{print $2}'`);
            console.log(`Container status: ${status}`);

            if (status !== 'Running') {
                throw new Error(`Container failed to start. Status: ${status}`);
            }

        } catch (lxcError) {
            console.error('LXC creation failed:', lxcError);

            // Clean up if LXC creation fails
            try {
                console.log('Cleaning up failed container...');
                await executeLXC(`lxc delete ${container_name} --force`);
            } catch (cleanupError) {
                console.error('Cleanup failed:', cleanupError);
            }

            throw new Error(`VPS creation failed: ${lxcError.message}`);
        }

        // Create VPS info object
        const configStr = `${ram}GB RAM / ${cpu} CPU / ${disk}GB Disk`;
        const osName = getOSName(os);

        const vpsInfo = {
            container_name: containerName,
            vps_name: vpsName,
            ram: `${ram}GB`,
            cpu: `${cpu}`,
            storage: `${disk}GB`,
            os: os,
            os_name: osName,
            config: configStr,
            status: 'running',
            suspended: false,
            suspension_history: [],
            created_at: new Date().toISOString(),
            shared_with: [],
            owner: username
        };

        // Add to user's VPS list
        vpsData[userId].push(vpsInfo);

        // Save updated data
        const saveResult = await saveVPSData(vpsData);
        if (!saveResult) {
            throw new Error('Failed to save VPS data');
        }

        console.log(`VPS created successfully: ${vpsName} (${containerName})`);

        // Send success response
        res.json({
            success: true,
            message: `VPS "${vpsName}" created successfully!`,
            data: {
                containerName: containerName,
                vpsName: vpsName,
                config: configStr,
                userId: userId,
                username: username
            }
        });

    } catch (error) {
        console.error('Create VPS error:', error);
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to create VPS'
        });
    }
});

// Helper function to get OS display name
function getOSName(osId) {
    const osMap = {
        'ubuntu:22.04': 'Ubuntu 22.04 LTS',
        'ubuntu:20.04': 'Ubuntu 20.04 LTS',
        'debian:12': 'Debian 12',
        'debian:11': 'Debian 11',
        'almalinux:9': 'AlmaLinux 9',
        'rockylinux:9': 'Rocky Linux 9'
    };

    return osMap[osId] || osId;
}

// Get VPS status
router.get('/status/:containerName', async (req, res) => {
    try {
        const { containerName } = req.params;

        const status = await executeLXC(`lxc info ${containerName} | grep "Status:" | awk '{print $2}'`);
        const ip = await executeLXC(`lxc list ${containerName} --format csv | cut -d, -f6`) || 'Not assigned';

        res.json({
            success: true,
            data: {
                status: status || 'unknown',
                ip: ip
            }
        });
    } catch (error) {
        console.error('Status check error:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to get VPS status'
        });
    }
});

// Get all VPS for a user
router.get('/user/:username', async (req, res) => {
    try {
        const { username } = req.params;
        const userId = getUserIdFromUsername(username);

        if (!userId) {
            return res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }

        const vpsData = await loadVPSData();
        const userVPS = vpsData[userId] || [];

        res.json({
            success: true,
            data: userVPS
        });
    } catch (error) {
        console.error('Get user VPS error:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to get user VPS'
        });
    }
});

// Health check
router.get('/health', async (req, res) => {
    try {
        // Check if LXC is available
        await executeLXC('lxc list --format json');

        res.json({
            success: true,
            message: 'VPS API is healthy',
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: 'LXC is not available'
        });
    }
});

// Get available OS templates
router.get('/templates', async (req, res) => {
    try {
        // This would typically list available LXC images
        // For now, return the static list from the frontend
        const templates = [
            { id: 'ubuntu:22.04', name: 'Ubuntu 22.04 LTS' },
            { id: 'ubuntu:20.04', name: 'Ubuntu 20.04 LTS' },
            { id: 'debian:12', name: 'Debian 12' },
            { id: 'debian:11', name: 'Debian 11' },
            { id: 'almalinux:9', name: 'AlmaLinux 9' },
            { id: 'rockylinux:9', name: 'Rocky Linux 9' }
        ];

        res.json({
            success: true,
            data: templates
        });
    } catch (error) {
        console.error('Error getting templates:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to get OS templates'
        });
    }
});

module.exports = router;