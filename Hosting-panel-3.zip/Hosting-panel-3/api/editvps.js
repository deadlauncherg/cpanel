const express = require('express');
const router = express.Router();
const { exec } = require('child_process');
const util = require('util');
const execAsync = util.promisify(exec);
const fs = require('fs');

// Load data functions
function loadVPSData() {
    try {
        if (fs.existsSync('vps_data.json')) {
            return JSON.parse(fs.readFileSync('vps_data.json', 'utf8'));
        }
    } catch (error) {
        console.error('Error loading VPS data:', error);
    }
    return {};
}

function saveVPSData(vpsData) {
    try {
        fs.writeFileSync('vps_data.json', JSON.stringify(vpsData, null, 4));
        return true;
    } catch (error) {
        console.error('Error saving VPS data:', error);
        return false;
    }
}

// Get VPS details
router.get('/:name', async (req, res) => {
    try {
        const containerName = req.params.name;
        const vpsData = loadVPSData();

        let vps = null;
        Object.keys(vpsData).forEach(userId => {
            const found = vpsData[userId].find(v => v.container_name === containerName);
            if (found) vps = found;
        });

        if (!vps) {
            return res.status(404).json({ success: false, error: 'VPS not found' });
        }

        // Get live stats
        try {
            const [status, ip, resources] = await Promise.all([
                execAsync(`lxc info ${containerName} | grep Status: | awk '{print $2}'`),
                execAsync(`lxc list ${containerName} --format csv | cut -d, -f6`),
                execAsync(`lxc config show ${containerName}`)
            ]);

            vps.liveStatus = status.stdout.trim();
            vps.ip = ip.stdout.trim();
            vps.resources = resources.stdout;
        } catch (execError) {
            console.error('Error getting live stats:', execError);
            vps.liveStatus = 'Unknown';
            vps.ip = 'Unknown';
        }

        res.json({ success: true, data: vps });
    } catch (error) {
        console.error('Get VPS error:', error);
        res.status(500).json({ success: false, error: 'Internal server error' });
    }
});

// Update VPS resources
router.put('/:name/resources', async (req, res) => {
    try {
        const containerName = req.params.name;
        const { ram, cpu, disk } = req.body;

        const vpsData = loadVPSData();
        let vps = null;
        let userId = null;

        Object.keys(vpsData).forEach(uid => {
            const found = vpsData[uid].find(v => v.container_name === containerName);
            if (found) {
                vps = found;
                userId = uid;
            }
        });

        if (!vps) {
            return res.status(404).json({ success: false, error: 'VPS not found' });
        }

        const changes = [];
        const wasRunning = vps.status === 'running' && !vps.suspended;

        try {
            // Stop VPS if running
            if (wasRunning) {
                await execAsync(`lxc stop ${containerName}`);
            }

            // Update RAM
            if (ram && ram > 0) {
                const ramMB = ram * 1024;
                await execAsync(`lxc config set ${containerName} limits.memory ${ramMB}MB`);
                changes.push(`RAM: ${ram}GB`);
                vps.ram = `${ram}GB`;
            }

            // Update CPU
            if (cpu && cpu > 0) {
                await execAsync(`lxc config set ${containerName} limits.cpu ${cpu}`);
                changes.push(`CPU: ${cpu} cores`);
                vps.cpu = cpu.toString();
            }

            // Update Disk
            if (disk && disk > 0) {
                await execAsync(`lxc config device set ${containerName} root size ${disk}GB`);
                changes.push(`Disk: ${disk}GB`);
                vps.storage = `${disk}GB`;
            }

            // Update config string
            const ramGB = parseInt(vps.ram);
            const cpuCores = parseInt(vps.cpu);
            const diskGB = parseInt(vps.storage);
            vps.config = `${ramGB}GB RAM / ${cpuCores} CPU / ${diskGB}GB Disk`;

            // Restart if it was running
            if (wasRunning) {
                await execAsync(`lxc start ${containerName}`);
            }

            // Save updated data
            if (saveVPSData(vpsData)) {
                res.json({ 
                    success: true, 
                    message: 'VPS resources updated successfully',
                    changes: changes
                });
            } else {
                res.status(500).json({ success: false, error: 'Failed to save VPS data' });
            }

        } catch (execError) {
            console.error('LXC command error:', execError);
            res.status(500).json({ 
                success: false, 
                error: `Failed to update VPS: ${execError.stderr || execError.message}` 
            });
        }

    } catch (error) {
        console.error('Update VPS error:', error);
        res.status(500).json({ success: false, error: 'Internal server error' });
    }
});

// VPS actions (start, stop, restart)
router.post('/:name/action', async (req, res) => {
    try {
        const containerName = req.params.name;
        const { action } = req.body;

        const validActions = ['start', 'stop', 'restart'];
        if (!validActions.includes(action)) {
            return res.status(400).json({ success: false, error: 'Invalid action' });
        }

        const vpsData = loadVPSData();
        let vps = null;

        Object.keys(vpsData).forEach(userId => {
            const found = vpsData[userId].find(v => v.container_name === containerName);
            if (found) vps = found;
        });

        if (!vps) {
            return res.status(404).json({ success: false, error: 'VPS not found' });
        }

        if (vps.suspended && action !== 'start') {
            return res.status(400).json({ success: false, error: 'Cannot perform action on suspended VPS' });
        }

        try {
            await execAsync(`lxc ${action} ${containerName}`);

            // Update status
            if (action === 'start') {
                vps.status = 'running';
                vps.suspended = false;
            } else if (action === 'stop') {
                vps.status = 'stopped';
            }

            if (saveVPSData(vpsData)) {
                res.json({ 
                    success: true, 
                    message: `VPS ${action}ed successfully`,
                    status: vps.status
                });
            } else {
                res.status(500).json({ success: false, error: 'Failed to save VPS data' });
            }

        } catch (execError) {
            console.error('LXC command error:', execError);
            res.status(500).json({ 
                success: false, 
                error: `Failed to ${action} VPS: ${execError.stderr || execError.message}` 
            });
        }

    } catch (error) {
        console.error('VPS action error:', error);
        res.status(500).json({ success: false, error: 'Internal server error' });
    }
});

// Suspend/Unsuspend VPS
router.post('/:name/suspend', async (req, res) => {
    try {
        const containerName = req.params.name;
        const { suspend } = req.body;

        const vpsData = loadVPSData();
        let vps = null;

        Object.keys(vpsData).forEach(userId => {
            const found = vpsData[userId].find(v => v.container_name === containerName);
            if (found) vps = found;
        });

        if (!vps) {
            return res.status(404).json({ success: false, error: 'VPS not found' });
        }

        vps.suspended = suspend;

        if (suspend && vps.status === 'running') {
            vps.status = 'stopped';
            try {
                await execAsync(`lxc stop ${containerName}`);
            } catch (execError) {
                console.error('Failed to stop VPS:', execError);
            }
        }

        if (saveVPSData(vpsData)) {
            res.json({ 
                success: true, 
                message: `VPS ${suspend ? 'suspended' : 'unsuspended'} successfully` 
            });
        } else {
            res.status(500).json({ success: false, error: 'Failed to save VPS data' });
        }

    } catch (error) {
        console.error('Suspend VPS error:', error);
        res.status(500).json({ success: false, error: 'Internal server error' });
    }
});

module.exports = router;