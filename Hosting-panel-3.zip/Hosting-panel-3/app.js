const express = require('express');
const session = require('express-session');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

// Load settings from settings.json
function loadSettings() {
    try {
        if (fs.existsSync('settings.json')) {
            return JSON.parse(fs.readFileSync('settings.json', 'utf8'));
        }
    } catch (error) {
        console.error('Error loading settings.json:', error);
    }

    // Default settings
    return {
        users: [
            {
                id: 1,
                username: 'admin',
                password: 'admin123',
                email: 'admin@chunkhost.com',
                role: 'admin',
                name: 'System Administrator',
                status: 'active',
                created: new Date().toISOString()
            }
        ],
        app: {
            name: 'ChunkHost',
            logo: 'https://avatars.githubusercontent.com/u/113706114?v=4'
        }
    };
}

// Save settings to settings.json
function saveSettings(settings) {
    try {
        fs.writeFileSync('settings.json', JSON.stringify(settings, null, 4));
        return true;
    } catch (error) {
        console.error('Error saving settings.json:', error);
        return false;
    }
}

// Load VPS data
function loadVPSData() {
    try {
        if (fs.existsSync('vps_data.json')) {
            return JSON.parse(fs.readFileSync('vps_data.json', 'utf8'));
        }
    } catch (error) {
        console.error('Error loading VPS data:', error);
    }
    return {};
}

// Save VPS data
function saveVPSData(vpsData) {
    try {
        fs.writeFileSync('vps_data.json', JSON.stringify(vpsData, null, 4));
        return true;
    } catch (error) {
        console.error('Error saving VPS data:', error);
        return false;
    }
}

const settings = loadSettings();
let users = settings.users;
let vpsData = loadVPSData();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// Session middleware
app.use(session({
    secret: 'chunkhost-secret-key-2024',
    resave: false,
    saveUninitialized: false,
    cookie: { 
        secure: false,
        maxAge: 24 * 60 * 60 * 1000
    }
}));

// Set EJS as template engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Authentication middleware
const requireAuth = (req, res, next) => {
    if (req.session.user) {
        next();
    } else {
        res.redirect('/login');
    }
};

const requireAdmin = (req, res, next) => {
    if (req.session.user && req.session.user.role === 'admin') {
        next();
    } else {
        res.status(403).json({ error: 'Admin access required' });
    }
};

// Routes

// Home route - redirect to login
app.get('/', (req, res) => {
    if (req.session.user) {
        res.redirect('/dashboard');
    } else {
        res.redirect('/login');
    }
});

// Login page
app.get('/login', (req, res) => {
    if (req.session.user) {
        return res.redirect('/dashboard');
    }
    res.render('login', { settings: settings.app });
});

// Login handler
app.post('/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        console.log('Login attempt:', { username, password });

        // Input validation
        if (!username || !password) {
            console.log('Missing credentials');
            return res.status(400).json({ error: 'Username and password are required' });
        }

        // Find user
        const user = users.find(u => u.username === username);
        console.log('Found user:', user);
        
        if (!user) {
            console.log('User not found');
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        // Check status if it exists
        if (user.status && user.status !== 'active') {
            console.log('User account suspended:', user.status);
            return res.status(401).json({ error: 'Account suspended. Please contact administrator.' });
        }

        // Password check
        console.log('Password check:', { input: password, stored: user.password });
        if (user.password !== password) {
            console.log('Password mismatch');
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        // Create session
        req.session.user = {
            id: user.id,
            username: user.username,
            email: user.email,
            role: user.role,
            name: user.name
        };

        console.log('Login successful for user:', user.username);
        res.json({ 
            message: 'Login successful',
            user: req.session.user
        });

    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Logout handler
app.post('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            return res.status(500).json({ error: 'Logout failed' });
        }
        res.json({ message: 'Logout successful' });
    });
});

// Dashboard
app.get('/dashboard', requireAuth, (req, res) => {
    const userVPS = vpsData[req.session.user.id] || [];

    res.render('dashboard', { 
        user: req.session.user,
        vpsList: userVPS,
        settings: settings.app,
        title: 'Dashboard - ChunkHost'
    });
});

// Admin Panel
app.get('/admin', requireAuth, requireAdmin, (req, res) => {
    res.render('admin', {
        user: req.session.user,
        settings: settings.app,
        title: 'Admin Panel - ChunkHost'
    });
});

// Create VPS Page
app.get('/create-vps', requireAuth, requireAdmin, (req, res) => {
    res.render('createvps', {
        user: req.session.user,
        settings: settings.app,
        title: 'Create VPS - ChunkHost'
    });
});

// Edit VPS Page
app.get('/edit-vps', requireAuth, (req, res) => {
    const containerName = req.query.name;

    if (!containerName) {
        return res.redirect('/dashboard');
    }

    // Find the VPS
    let vps = null;
    Object.keys(vpsData).forEach(userId => {
        const found = vpsData[userId].find(v => v.container_name === containerName);
        if (found) vps = found;
    });

    if (!vps) {
        return res.status(404).render('error', { 
            user: req.session.user,
            error: 'VPS not found',
            title: 'Error - ChunkHost'
        });
    }

    // Check permissions
    if (req.session.user.role !== 'admin' && vps.owner !== req.session.user.username) {
        return res.status(403).render('error', {
            user: req.session.user,
            error: 'Access denied',
            title: 'Error - ChunkHost'
        });
    }

    res.render('edit', {
        user: req.session.user,
        vps: vps,
        settings: settings.app,
        title: `Edit ${vps.name || vps.container_name} - ChunkHost`
    });
});

// API Routes

// Admin API
app.use('/api/admin', requireAuth, requireAdmin, require('./api/admin'));

// Create VPS API
app.use('/api/createvps', requireAuth, requireAdmin, require('./api/createvps'));

// Edit VPS API
app.use('/api/editvps', requireAuth, require('./api/editvps'));

// User VPS API
app.get('/api/my-vps', requireAuth, (req, res) => {
    const userVPS = vpsData[req.session.user.id] || [];
    res.json({ success: true, data: userVPS });
});

// VPS Actions API
app.post('/api/vps/:name/:action', requireAuth, async (req, res) => {
    try {
        const containerName = req.params.name;
        const action = req.params.action;
        const validActions = ['start', 'stop', 'restart'];

        if (!validActions.includes(action)) {
            return res.status(400).json({ success: false, error: 'Invalid action' });
        }

        // Find VPS and check permissions
        let vps = null;
        let userId = null;

        Object.keys(vpsData).forEach(uid => {
            const found = vpsData[uid].find(v => v.container_name === containerName);
            if (found) {
                vps = found;
                userId = uid;
            }
        });

        if (!vps) {
            return res.status(404).json({ success: false, error: 'VPS not found' });
        }

        // Check permissions
        if (req.session.user.role !== 'admin' && userId !== req.session.user.id) {
            return res.status(403).json({ success: false, error: 'Access denied' });
        }

        if (vps.suspended) {
            return res.status(400).json({ success: false, error: 'Cannot perform action on suspended VPS' });
        }

        // Execute LXC command
        const { exec } = require('child_process');
        const util = require('util');
        const execAsync = util.promisify(exec);

        try {
            await execAsync(`lxc ${action} ${containerName}`);

            // Update status
            if (action === 'start') {
                vps.status = 'running';
            } else if (action === 'stop') {
                vps.status = 'stopped';
            }

            saveVPSData(vpsData);

            res.json({ 
                success: true, 
                message: `VPS ${action}ed successfully`,
                status: vps.status
            });

        } catch (execError) {
            console.error('LXC command error:', execError);
            res.status(500).json({ 
                success: false, 
                error: `Failed to ${action} VPS: ${execError.stderr || execError.message}` 
            });
        }

    } catch (error) {
        console.error('VPS action error:', error);
        res.status(500).json({ success: false, error: 'Internal server error' });
    }
});

// Get VPS Stats
app.get('/api/vps/:name/stats', requireAuth, async (req, res) => {
    try {
        const containerName = req.params.name;

        // Find VPS and check permissions
        let vps = null;
        let userId = null;

        Object.keys(vpsData).forEach(uid => {
            const found = vpsData[uid].find(v => v.container_name === containerName);
            if (found) {
                vps = found;
                userId = uid;
            }
        });

        if (!vps) {
            return res.status(404).json({ success: false, error: 'VPS not found' });
        }

        // Check permissions
        if (req.session.user.role !== 'admin' && userId !== req.session.user.id) {
            return res.status(403).json({ success: false, error: 'Access denied' });
        }

        const { exec } = require('child_process');
        const util = require('util');
        const execAsync = util.promisify(exec);

        try {
            // Get container status
            const statusResult = await execAsync(`lxc info ${containerName} | grep Status: | awk '{print $2}'`);
            const status = statusResult.stdout.trim();

            // Get IP address
            const ipResult = await execAsync(`lxc list ${containerName} --format csv | cut -d, -f6`);
            const ip = ipResult.stdout.trim();

            res.json({
                success: true,
                data: {
                    status: status,
                    ip: ip,
                    suspended: vps.suspended,
                    ...vps
                }
            });

        } catch (execError) {
            console.error('LXC command error:', execError);
            res.json({
                success: true,
                data: {
                    status: 'Unknown',
                    ip: 'Unknown',
                    suspended: vps.suspended,
                    ...vps
                }
            });
        }

    } catch (error) {
        console.error('VPS stats error:', error);
        res.status(500).json({ success: false, error: 'Internal server error' });
    }
});

// Settings API
app.get('/api/settings', requireAuth, requireAdmin, (req, res) => {
    res.json({ success: true, data: settings });
});

app.post('/api/settings', requireAuth, requireAdmin, (req, res) => {
    try {
        const newSettings = req.body;
        Object.assign(settings, newSettings);

        if (saveSettings(settings)) {
            users = settings.users; // Update users array
            res.json({ success: true, message: 'Settings updated successfully', data: settings });
        } else {
            res.status(500).json({ success: false, error: 'Failed to save settings' });
        }
    } catch (error) {
        res.status(500).json({ success: false, error: 'Error updating settings' });
    }
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: 'Something went wrong!' });
});

// 404 handler
app.use((req, res) => {
    res.status(404).json({ error: 'Route not found' });
});

// Initialize data files
function initializeDataFiles() {
    if (!fs.existsSync('vps_data.json')) {
        fs.writeFileSync('vps_data.json', JSON.stringify({}, null, 4));
    }
    if (!fs.existsSync('settings.json')) {
        saveSettings(settings);
    }
}

// Start server
app.listen(PORT, () => {
    initializeDataFiles();
    console.log(`🚀 ChunkHost Panel running on http://localhost:${PORT}`);
    console.log('📋 Demo credentials:');
    console.log('   Admin: admin / admin123');
    console.log('💡 Features:');
    console.log('   - User Management');
    console.log('   - VPS Creation & Management');
    console.log('   - LXC Integration');
    console.log('   - Admin Panel');
});

module.exports = app;